# 🏏 NSL S2 — National Super League Season 2 Tournament Arena

A tournament management system and enterprise cricket scoring engine engineered specifically for **NSL Season 2 (National Super League)** tapeball championship.

---

## 🏆 Tournament Overview

- **Franchises**: 4 Teams (**Khan Tigers**, **Arslan Aslam Super Kings**, **Nawab Kings**, **Ali Waly**)
- **Format**: 6 Round 1 Group Matches + Knockout Playoff Qualifier + Grand Final
- **Rules**: Tapeball 8-over matches with Free Hits, standard ICC Net Run Rate (NRR), and dynamic playoff qualification.

---

## 🚀 Key Implementations by Phase

### Phase 1 — Scoring Engine & Reliability
- **Isolated Playoff Standings**: Playoff matches (`m.isPlayoff: true`) are strictly excluded from Round 1 group standings. Only Round 1 fixtures count toward group points, net run rate, and seeding.
- **Pre-Match Setup & Playing Squad Selection**: Scorer selects coin toss winner & decision (bat/bowl), sets overs quota (default 8 overs), selects active Playing Squad (8-11 players per team), and picks opening batsmen and opening bowler.
- **Accurate All-Out & Innings-Ending Conditions**: Auto-detects all-out when wickets reach `Playing Squad count - 1` (or 10 wkts). Cleanly transitions from 1st innings to Innings Break and finalizes 2nd innings upon target chased or overs completed.
- **Standard ICC Net Run Rate (NRR) Formula**:
  $$\text{NRR} = \frac{\text{Runs Scored}}{\text{Overs Faced}} - \frac{\text{Runs Conceded}}{\text{Overs Bowled}}$$
  *All-out teams count full quota of overs allocated. Successfully chasing teams count actual decimal overs faced.*
- **Complete Extras & Dismissals**:
  - One-tap Wide (`WD +1`) with runner support.
  - No-Ball (`NB +1`) with automatic Free Hit award.
  - Byes (`B`) & Leg-Byes (`LB`) (+1, +2, +3, +4) counted to team total without charging bowler's figures.
  - Dismissals: Bowled, Caught, LBW, Stumped, Run Out (striker/non-striker + completed runs), Hit Wicket, Retired. On Free Hit, only Run Out is legally permitted.
- **Deep Undo System**: Immutable state stack snapshots every ball and over boundary, restoring every single metric (batsman runs, balls, 4s, 6s, bowler balls, runs, maidens, wickets, extras breakdown, striker positions, commentary).
- **Match Result Validation**: Pre-save verification screen shows final margin, recommended Player of the Match, and locks score into database.

### Phase 2 — Backend & Permissions
- **Real SQLite Database & API**: Endpoints for matches, completed match archives, schedule, teams, announcements, audit logs, and backups.
- **Role-Based Access Control**:
  - **👑 Admin** (PIN: `7860`): Full tournament management, reset data, post announcements, backup/restore.
  - **⚡ Scorer** (PIN: `1234`): Live match scoring, toss setup, ball recording, undo, match validation.
  - **👁 Spectator** (No PIN): Read-only live match centre, commentary, standings, leaderboards, and scorecards.
- **Live Sync**: 1.5-second live polling between ground scorer and spectator devices.
- **Audit Logging**: Every ball recorded, undo executed, emergency player added, and result finalized is timestamped in the audit trail.
- **Match History & Backups**: 1-click JSON backup export and restore.

### Phase 3 — Professional NSL Interface
- **NSL Home Dashboard**: Hero live match card, quick tournament stats, Cap leaderboards preview, announcements, and points glance.
- **Live Match Centre**: Ball-by-ball score badges (`•`, `1`, `4`, `6`, `W`, `wd`, `nb`, `b`, `lb`), live commentary feed, completed overs accordion, and scorecard tabs.
- **Points Table & Dynamic Playoff Bracket**: Round 1 table with form guides (W/L/T), qualification badges (Direct Final, Knockout Qualifier, Eliminated), and visual bracket tree advancing teams into the Grand Final.
- **Cap Awards**:
  - 🟠 **Orange Cap**: Top run-scorer leaderboard.
  - 🟣 **Purple Cap**: Leading wicket-taker leaderboard.
  - 💥 **Maximum Sixes**: Six-hitter leaderboard.
  - 👑 **Tournament MVP**: Points-weighted player impact index.
- **Franchise & Player Profiles**: Squad lists and individual player tournament statistics (runs, innings, strike rate, high score, sixes, wickets, economy).

### Phase 4 — Tournament Presentation
- **Contextual Ball Commentary**: Automated narrative descriptions for every delivery.
- **Shareable WhatsApp Scorecards**: 1-click formatted match update ready to copy and paste into WhatsApp groups.
- **Team Logos & PWA**: High-res franchise logos (`KTG`, `ASK`, `NKG`, `ALW`), web app manifest, and offline service worker caching all assets.

---

## 🏃 Running the Application

### Option A: Local Unified Server (Frontend + API in 1 process)
```bash
python server.py
```
Open **http://localhost:8000** in your browser or phone on the same Wi-Fi.

### Option B: Standalone VPS Backend API
```bash
python vps_backend.py
```
Runs API on port 5000 with SQLite database `tapeball.db`.

---

## 📱 Role PINs & Credentials

- **Admin Master PIN**: `7860`
- **Ground Scorer PIN**: `1234`
- **Spectator Access**: Open (No PIN required)
